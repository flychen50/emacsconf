/* 
 * This file contains a few misc prototypes for declarations in other parts
 * of the cpp-root project type.
 */

#ifdef FEATURE1
int feature1();
#endif

#ifdef FEATURE2
int feature2();
#endif

#ifdef FEATURE3
int feature3();
#endif

int generic_feature();

