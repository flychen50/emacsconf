/* Fake emacs.c for faking out EDE tests */
