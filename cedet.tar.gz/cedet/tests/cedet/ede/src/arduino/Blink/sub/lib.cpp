// C file in a sub directory of an arduino lib.
